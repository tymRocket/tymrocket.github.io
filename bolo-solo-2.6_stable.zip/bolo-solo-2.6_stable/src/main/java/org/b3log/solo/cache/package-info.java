/**
 * Cache.
 */
package org.b3log.solo.cache;
