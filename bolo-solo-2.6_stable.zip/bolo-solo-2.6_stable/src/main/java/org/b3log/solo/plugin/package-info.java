/**
 * Plugins.
 */
package org.b3log.solo.plugin;
