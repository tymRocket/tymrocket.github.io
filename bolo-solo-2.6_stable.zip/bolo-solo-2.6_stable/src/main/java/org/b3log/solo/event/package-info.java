/**
 * Event handlers.
 */
package org.b3log.solo.event;
